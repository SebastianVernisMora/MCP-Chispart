#!/usr/bin/env node
// TUI mínima sin dependencias: lista tareas, muestra timeline y ejecuta actions
import { readFileSync, existsSync } from 'fs';
import { join } from 'path';
import { spawnSync } from 'child_process';

const ROOT = process.cwd();
const STATE = join(ROOT, '.mcp', 'state');
const TASKS = join(STATE, 'tasks.json');
const TIMELINE = join(STATE, 'timeline.jsonl');

function cls() { process.stdout.write('\u001b[2J\u001b[0;0H'); }
function nowISO() { return new Date().toISOString(); }
function safeJson(path) { try { return JSON.parse(readFileSync(path, 'utf-8')); } catch { return null; } }
function tailTimeline(n = 200) {
  try {
    const lines = readFileSync(TIMELINE, 'utf-8').trim().split('\n');
    return lines.slice(-n).map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  } catch { return []; }
}

function runOrch(args = []) {
  const res = spawnSync('node', ['scripts/chispart-mcp/orchestrator.mjs', ...args], { encoding: 'utf-8' });
  return { code: res.status, out: res.stdout, err: res.stderr };
}

function render(tasks, events) {
  cls();
  process.stdout.write('MCP TUI – (q=salir, p=pump, l=list, c=cerrar, n=nueva)\n');
  process.stdout.write('Tareas:\n');
  for (const t of tasks?.tasks || []) {
    const id = (t.id || '').slice(0,8);
    process.stdout.write(`  ${id} | ${t.repo || ''} | ${t.status || ''} | ${t.title || ''}\n`);
  }
  process.stdout.write('\nTimeline (reciente):\n');
  for (const e of events.slice(-10).reverse()) {
    const type = e?.envelope?.type || e.event || '';
    const from = e?.from || e?.envelope?.agent?.name || 'orchestrator';
    const tid = e?.envelope?.task?.id || '';
    process.stdout.write(`  [${e.ts}] ${type} from=${from}${tid ? ' task=' + tid.slice(0,8)+'…' : ''}\n`);
  }
  process.stdout.write('\n> ');
}

function ask(prompt) {
  process.stdout.write(prompt);
  const buf = []; let chunk;
  while ((chunk = Buffer.alloc(1)) && fsRead(0, chunk) > 0) {
    const c = chunk.toString('utf8');
    if (c === '\n' || c === '\r') break; buf.push(c);
  }
  return buf.join('').trim();
}

function fsRead(fd, buf) { try { return require('fs').readSync(fd, buf, 0, buf.length, null); } catch { return -1; } }

async function main() {
  if (!existsSync(STATE)) { console.error('No existe .mcp/state. Ejecuta init/agents en esta copia.'); process.exit(1); }
  let lastRender = nowISO();
  while (true) {
    const tasks = safeJson(TASKS) || { tasks: [] };
    const events = tailTimeline(100);
    render(tasks, events);
    const cmd = ask('');
    if (cmd === 'q') break;
    if (cmd === 'p') { runOrch(['pump']); }
    else if (cmd === 'l') { /* re-render next loop */ }
    else if (cmd === 'c') {
      const id = ask('task id> ');
      if (id) runOrch(['tasks', 'close', id, '--status', 'done']);
    }
    else if (cmd === 'n') {
      const title = ask('titulo> ');
      const repo = ask('repo> ');
      if (title && repo) runOrch(['task', title, '--repo', repo]);
    }
  }
}

main();

