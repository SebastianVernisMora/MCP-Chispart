<?php
// API sencilla para leer/escribir estado del MCP.
// Nota: las acciones invocan el orquestador vía shell y requieren Node en PATH.

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$root = realpath(__DIR__ . '/..');
$stateRoot = $root . DIRECTORY_SEPARATOR . '.mcp' . DIRECTORY_SEPARATOR . 'state';
$tasksFile = $stateRoot . DIRECTORY_SEPARATOR . 'tasks.json';
$timelineFile = $stateRoot . DIRECTORY_SEPARATOR . 'timeline.jsonl';
$wrapper = $root . DIRECTORY_SEPARATOR . 'chispart_mcp.sh';
$agentsCfg = $root . DIRECTORY_SEPARATOR . 'scripts' . DIRECTORY_SEPARATOR . 'chispart-mcp' . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'agents.json';

function out($data, $code = 200) {
  http_response_code($code);
  echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
  exit;
}

function safeStr($s) { return is_string($s) ? trim($s) : ''; }

function uuidv4() {
  $data = random_bytes(16);
  $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
  $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
  return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

function run_wrapper($args) {
  global $root, $wrapper;
  $cmd = 'cd ' . escapeshellarg($root) . ' && bash ' . escapeshellarg($wrapper) . ' ' . $args . ' 2>&1';
  $lines = [];
  $code = 0;
  @exec($cmd, $lines, $code);
  return [ 'ok' => $code === 0, 'code' => $code, 'output' => implode("\n", $lines) ];
}

$action = isset($_GET['action']) ? $_GET['action'] : 'tasks';

if ($action === 'tasks') {
  if (!file_exists($tasksFile)) out([ 'tasks' => [] ]);
  $json = json_decode(file_get_contents($tasksFile), true);
  out($json ?: [ 'tasks' => [] ]);
}

if ($action === 'timeline') {
  $since = isset($_GET['since']) ? safeStr($_GET['since']) : '';
  if (!file_exists($timelineFile)) out([]);
  $lines = array_filter(explode("\n", trim(file_get_contents($timelineFile))));
  $events = [];
  foreach (array_slice($lines, -300) as $line) {
    $j = json_decode($line, true);
    if (!$j) continue;
    if (!$since || (isset($j['ts']) && $j['ts'] > $since)) $events[] = $j;
  }
  out($events);
}

if ($action === 'taskShow') {
  $id = isset($_GET['id']) ? safeStr($_GET['id']) : '';
  if (!$id) out([ 'error' => 'Falta id' ], 400);
  $res = run_wrapper('tasks show ' . escapeshellarg($id));
  $json = json_decode($res['output'] ?? '', true);
  if ($res['ok'] && $json) out([ 'ok' => true, 'task' => $json ], 200);
  // Fallback: leer de estado local
  if (!file_exists($tasksFile)) out([ 'ok' => false, 'error' => 'No hay estado de tareas' ], 500);
  $store = json_decode(file_get_contents($tasksFile), true);
  $t = null;
  if (is_array($store['tasks'] ?? null)) {
    foreach ($store['tasks'] as $it) { if (($it['id'] ?? '') === $id) { $t = $it; break; } }
  }
  out([ 'ok' => (bool)$t, 'task' => $t ], $t ? 200 : 404);
}

// --- Repos: listar y habilitar ---
if ($action === 'repos') {
  if (!file_exists($agentsCfg)) out([ 'repos' => [] ]);
  $cfg = json_decode(file_get_contents($agentsCfg), true);
  $repos = [];
  if (is_array($cfg['agents'] ?? null)) {
    foreach ($cfg['agents'] as $a) {
      if (is_array($a['repos'] ?? null)) {
        foreach ($a['repos'] as $r) { $repos[$r] = true; }
      }
    }
  }
  $list = array_values(array_keys($repos));
  sort($list);
  out([ 'repos' => $list ]);
}

if ($action === 'reposAdd') {
  $name = isset($_GET['name']) ? safeStr($_GET['name']) : '';
  if (!$name) out([ 'error' => 'Falta nombre de repo' ], 400);
  // Validación simple: letras, números, guiones y puntos
  if (!preg_match('/^[A-Za-z0-9_.-]{2,64}$/', $name)) out([ 'error' => 'Nombre inválido' ], 400);
  if (!file_exists($agentsCfg)) out([ 'error' => 'Config de agentes no encontrada' ], 500);
  $cfg = json_decode(file_get_contents($agentsCfg), true);
  if (!is_array($cfg)) out([ 'error' => 'Config inválida' ], 500);
  $changed = false;
  if (is_array($cfg['agents'] ?? null)) {
    foreach ($cfg['agents'] as &$a) {
      if (!isset($a['repos']) || !is_array($a['repos'])) $a['repos'] = [];
      if (!in_array($name, $a['repos'], true)) { $a['repos'][] = $name; $changed = true; }
    }
    unset($a);
  }
  if ($changed) {
    // Guardar con pretty print y slashes sin escapar
    $ok = @file_put_contents($agentsCfg, json_encode($cfg, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
    if ($ok === false) out([ 'error' => 'No se pudo escribir agents.json' ], 500);
  }
  // Responder lista actualizada
  $repos = [];
  foreach ($cfg['agents'] as $a) { foreach ($a['repos'] as $r) { $repos[$r] = true; } }
  $list = array_values(array_keys($repos)); sort($list);
  out([ 'ok' => true, 'changed' => $changed, 'repos' => $list ]);
}

// Acciones que requieren shell
if (!is_executable($wrapper)) {
  // permitir aunque no sea ejecutable (se invocará con bash)
}

if ($action === 'pump') {
  $res = run_wrapper('pump');
  if ($res['ok']) out($res, 200);
  // Fallback: simular pump y registrar en timeline
  $now = date('c');
  @mkdir($stateRoot, 0777, true);
  if (!file_exists($timelineFile)) @file_put_contents($timelineFile, "");
  @file_put_contents($timelineFile, json_encode([ 'ts' => $now, 'event' => 'pump.fallback', 'envelope' => [ 'id' => uuidv4(), 'type' => 'log.info', 'agent' => [ 'name' => 'ui-web', 'role' => 'client' ], 'payload' => [ 'note' => 'pump fallback (wrapper no disponible)' ], 'meta' => [ 'timestamp' => $now, 'version' => '2.0' ] ] ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND);
  out([ 'ok' => true, 'fallback' => true, 'result' => [ 'pumped' => true, 'routed' => 0 ] ], 200);
}

if ($action === 'createTask') {
  $title = isset($_GET['title']) ? safeStr($_GET['title']) : '';
  $repo = isset($_GET['repo']) ? safeStr($_GET['repo']) : '';
  if (!$title || !$repo) out([ 'error' => 'Faltan title y repo' ], 400);
  // Intentar con wrapper primero
  $res = run_wrapper('task ' . escapeshellarg($title) . ' ' . escapeshellarg($repo));
  if ($res['ok']) out($res, 200);
  // Fallback: creación directa en estado si wrapper falla (p.ej. Node < 18)
  @mkdir($stateRoot, 0777, true);
  if (!file_exists($tasksFile)) @file_put_contents($tasksFile, json_encode([ 'tasks' => [] ], JSON_PRETTY_PRINT));
  $store = json_decode(@file_get_contents($tasksFile), true);
  if (!is_array($store)) $store = [ 'tasks' => [] ];
  if (!is_array($store['tasks'] ?? null)) $store['tasks'] = [];
  $now = date('c');
  $task = [
    'id' => uuidv4(),
    'title' => $title,
    'description' => '',
    'repo' => $repo,
    'status' => 'pending',
    'createdAt' => $now,
    'updatedAt' => $now,
    'updates' => []
  ];
  $store['tasks'][] = $task;
  @file_put_contents($tasksFile, json_encode($store, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
  // Timeline
  $env = [
    'id' => uuidv4(),
    'type' => 'task.create',
    'agent' => [ 'name' => 'ui-web', 'role' => 'client' ],
    'task' => [ 'id' => $task['id'], 'title' => $title, 'repo' => $repo, 'status' => 'pending' ],
    'payload' => new stdClass(),
    'meta' => [ 'timestamp' => $now, 'version' => '2.0' ]
  ];
  @file_put_contents($timelineFile, json_encode([ 'ts' => $now, 'event' => 'task.create', 'envelope' => $env ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND);
  out([ 'ok' => true, 'fallback' => true, 'task' => $task ]);
}

if ($action === 'closeTask') {
  $id = isset($_GET['id']) ? safeStr($_GET['id']) : '';
  $status = isset($_GET['status']) ? safeStr($_GET['status']) : 'done';
  if (!$id) out([ 'error' => 'Falta id' ], 400);
  $res = run_wrapper('tasks close ' . escapeshellarg($id) . ' --status ' . escapeshellarg($status));
  if ($res['ok']) out($res, 200);
  // Fallback: actualizar estado local
  if (!file_exists($tasksFile)) out([ 'error' => 'No hay estado de tareas' ], 500);
  $store = json_decode(file_get_contents($tasksFile), true);
  if (!is_array($store['tasks'] ?? null)) out([ 'error' => 'Estado inválido' ], 500);
  $found = false; $now = date('c');
  foreach ($store['tasks'] as &$it) {
    if (($it['id'] ?? '') === $id) {
      $it['status'] = $status ?: 'done';
      $it['updatedAt'] = $now;
      if (!isset($it['updates']) || !is_array($it['updates'])) $it['updates'] = [];
      $it['updates'][] = [ 'at' => $now, 'from' => 'ui-web', 'type' => 'task.update', 'payload' => [ 'status' => $it['status'] ] ];
      $found = true; break;
    }
  }
  unset($it);
  if (!$found) out([ 'error' => 'Tarea no encontrada' ], 404);
  @file_put_contents($tasksFile, json_encode($store, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
  @file_put_contents($timelineFile, json_encode([ 'ts' => $now, 'event' => 'task.update', 'envelope' => [ 'id' => uuidv4(), 'type' => 'task.update', 'agent' => [ 'name' => 'ui-web', 'role' => 'client' ], 'task' => [ 'id' => $id ], 'payload' => [ 'status' => $status ], 'meta' => [ 'timestamp' => $now, 'version' => '2.0' ] ] ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND);
  out([ 'ok' => true, 'updated' => true ]);
}

if ($action === 'sendChange') {
  $title = isset($_GET['title']) ? safeStr($_GET['title']) : '';
  $repo = isset($_GET['repo']) ? safeStr($_GET['repo']) : '';
  $roles = isset($_GET['roles']) ? safeStr($_GET['roles']) : '';
  $payload = isset($_GET['payload']) ? $_GET['payload'] : '';
  $prefix = isset($_GET['prefix']) ? $_GET['prefix'] : '';
  $suffix = isset($_GET['suffix']) ? $_GET['suffix'] : '';
  if (!$repo || (!$title && !$payload)) out([ 'error' => 'Faltan repo y título o payload' ], 400);
  $args = 'send change ' . escapeshellarg($title ?: 'Change Request') . ' --repo ' . escapeshellarg($repo);
  if ($roles) $args .= ' --roles ' . escapeshellarg($roles);
  if ($payload) $args .= ' --payload ' . escapeshellarg($payload);
  if ($prefix) $args .= ' --prefix ' . escapeshellarg($prefix);
  if ($suffix) $args .= ' --suffix ' . escapeshellarg($suffix);
  $res = run_wrapper($args);
  out($res, $res['ok'] ? 200 : 500);
}

if ($action === 'tasksReport') {
  $id = isset($_GET['id']) ? safeStr($_GET['id']) : '';
  if (!$id) out([ 'error' => 'Falta id' ], 400);
  $res = run_wrapper('tasks report ' . escapeshellarg($id));
  $json = json_decode($res['output'] ?? '', true);
  out([ 'ok' => $res['ok'], 'summary' => $json ?: null, 'raw' => $res['output'] ], $res['ok'] ? 200 : 500);
}

if ($action === 'tasksPlan') {
  $id = isset($_GET['id']) ? safeStr($_GET['id']) : '';
  if (!$id) out([ 'error' => 'Falta id' ], 400);
  $res = run_wrapper('tasks plan ' . escapeshellarg($id));
  $json = json_decode($res['output'] ?? '', true);
  out([ 'ok' => $res['ok'], 'plan' => $json ?: null, 'raw' => $res['output'] ], $res['ok'] ? 200 : 500);
}

if ($action === 'nlExec') {
  $text = isset($_GET['text']) ? safeStr($_GET['text']) : '';
  $repo = isset($_GET['repo']) ? safeStr($_GET['repo']) : '';
  $roles = isset($_GET['roles']) ? safeStr($_GET['roles']) : '';
  if (!$text) out([ 'error' => 'Falta text' ], 400);
  $args = 'nl exec ' . escapeshellarg($text);
  if ($repo) $args .= ' --repo ' . escapeshellarg($repo);
  if ($roles) $args .= ' --roles ' . escapeshellarg($roles);
  $res = run_wrapper($args);
  $json = json_decode($res['output'] ?? '', true);
  out([ 'ok' => $res['ok'], 'result' => $json ?: null, 'raw' => $res['output'] ], $res['ok'] ? 200 : 500);
}

// Paginación de tareas para Chat NL y UI
if ($action === 'tasksPaged') {
  $page = max(1, intval($_GET['page'] ?? 1));
  $size = max(1, min(200, intval($_GET['size'] ?? 20)));
  if (!file_exists($tasksFile)) out([ 'items' => [], 'page' => $page, 'size' => $size, 'total' => 0, 'pages' => 0 ]);
  $store = json_decode(file_get_contents($tasksFile), true);
  $arr = is_array($store['tasks'] ?? null) ? $store['tasks'] : [];
  // Ordenar por updatedAt asc y tomar últimas primero
  usort($arr, function($a,$b){ return strcmp(strval($a['updatedAt'] ?? ''), strval($b['updatedAt'] ?? '')); });
  $total = count($arr);
  $pages = $total ? intval(ceil($total / $size)) : 0;
  $start = max(0, ($page - 1) * $size);
  $slice = array_slice($arr, $start, $size);
  $items = array_map(function($t){ return [
    'id' => $t['id'] ?? '',
    'repo' => $t['repo'] ?? '',
    'status' => $t['status'] ?? '',
    'title' => $t['title'] ?? '',
    'updatedAt' => $t['updatedAt'] ?? '',
  ]; }, $slice);
  out([ 'items' => $items, 'page' => $page, 'size' => $size, 'total' => $total, 'pages' => $pages ]);
}

// Chat embebido (sesiones persistentes)
if ($action === 'chatNew') {
  $cmdNode = 'node scripts/chispart-mcp/chat_api.mjs new';
  $cmdScript = 'scripts/chispart-mcp/chat_api.mjs new';
  $bash = 'bash -lc ' . escapeshellarg('if [ -s "$HOME/.nvm/nvm.sh" ]; then . "$HOME/.nvm/nvm.sh"; fi; if [ -f ./.env ]; then set -a; . ./.env; set +a; fi; if command -v nvm >/dev/null 2>&1; then NODE=$(nvm which 20); "$NODE" '.$cmdScript.'; else '.$cmdNode.'; fi');
  $lines = [];
  $code = 0; @exec('cd ' . escapeshellarg($root) . ' && ' . $bash . ' 2>&1', $lines, $code);
  $outTxt = implode("\n", $lines);
  $json = json_decode($outTxt, true);
  out($json ?: [ 'ok' => false, 'raw' => $outTxt ], $code === 0 ? 200 : 500);
}
if ($action === 'chatSend') {
  $session = isset($_GET['session']) ? safeStr($_GET['session']) : '';
  $text = isset($_GET['text']) ? $_GET['text'] : '';
  if (!$session || !$text) out([ 'error' => 'Faltan session y text' ], 400);
  $cmdNode = 'node scripts/chispart-mcp/chat_api.mjs send ' . escapeshellarg($session) . ' ' . escapeshellarg($text);
  $cmdScript = 'scripts/chispart-mcp/chat_api.mjs send ' . escapeshellarg($session) . ' ' . escapeshellarg($text);
  $bash = 'bash -lc ' . escapeshellarg('if [ -s "$HOME/.nvm/nvm.sh" ]; then . "$HOME/.nvm/nvm.sh"; fi; if [ -f ./.env ]; then set -a; . ./.env; set +a; fi; if command -v nvm >/dev/null 2>&1; then NODE=$(nvm which 20); "$NODE" '.$cmdScript.'; else '.$cmdNode.'; fi');
  $lines = []; $code = 0; @exec('cd ' . escapeshellarg($root) . ' && ' . $bash . ' 2>&1', $lines, $code);
  $outTxt = implode("\n", $lines); $json = json_decode($outTxt, true);
  out($json ?: [ 'ok' => false, 'raw' => $outTxt ], $code === 0 ? 200 : 500);
}
if ($action === 'chatLog') {
  $session = isset($_GET['session']) ? safeStr($_GET['session']) : '';
  if (!$session) out([ 'error' => 'Falta session' ], 400);
  $file = $root . DIRECTORY_SEPARATOR . '.mcp' . DIRECTORY_SEPARATOR . 'chats' . DIRECTORY_SEPARATOR . $session . DIRECTORY_SEPARATOR . 'log.jsonl';
  if (!file_exists($file)) out([ 'events' => [] ]);
  $lines = array_filter(explode("\n", trim(file_get_contents($file))));
  $events = [];
  foreach (array_slice($lines, -200) as $line) { $j = json_decode($line, true); if ($j) $events[] = $j; }
  out([ 'events' => $events ]);
}

out([ 'error' => 'Acción no soportada' ], 400);
