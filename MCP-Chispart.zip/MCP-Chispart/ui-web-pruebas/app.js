(() => {
  const tasksTable = document.querySelector('#tasks tbody');
  const timelineDiv = document.querySelector('#timeline');
  const btnPump = document.querySelector('#btn-pump');
  const btnCreate = document.querySelector('#btn-create');
  const inpTitle = document.querySelector('#new-title');
  const repoSelect = document.querySelector('#new-repo');
  const watchToggle = document.querySelector('#watch-toggle');
  const detailEl = document.querySelector('#task-detail');
  const btnReport = document.querySelector('#btn-report');
  const btnPlan = document.querySelector('#btn-plan');
  const newRepoName = document.querySelector('#new-repo-name');
  const btnAddRepo = document.querySelector('#btn-add-repo');
  const btnTheme = document.querySelector('#btn-theme');
  const hideClosedToggle = document.querySelector('#hide-closed');
  const tasksCount = document.querySelector('#tasks-count');

  // Changes
  const chgTitle = document.querySelector('#chg-title');
  const chgRepo = document.querySelector('#chg-repo');
  const chgRoles = document.querySelector('#chg-roles');
  const chgPayload = document.querySelector('#chg-payload');
  const chgPrefix = document.querySelector('#chg-prefix');
  const chgSuffix = document.querySelector('#chg-suffix');
  const btnSendChange = document.querySelector('#btn-send-change');
  const chgResult = document.querySelector('#chg-result');

  // Chat NL
  const chatText = document.querySelector('#chat-text');
  const chatRepo = document.querySelector('#chat-repo');
  const btnChatSend = document.querySelector('#btn-chat-send');
  const btnChatNew = document.querySelector('#btn-chat-new');
  const chatLog = document.querySelector('#chat-log');
  let chatSession = localStorage.getItem('chatSessionId') || '';
  const chatTasksDiv = document.querySelector('#chat-tasks');
  const chatPageInput = document.querySelector('#chat-page');
  const chatSizeInput = document.querySelector('#chat-size');
  const btnChatList = document.querySelector('#btn-chat-list');
  const btnChatPrev = document.querySelector('#btn-chat-prev');
  const btnChatNext = document.querySelector('#btn-chat-next');

  let lastTs = new Date().toISOString();

  async function fetchJson(url) {
    const res = await fetch(url);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return res.json();
  }

  function toast(msg, ms = 3000) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), ms);
  }

  // Repos
  async function loadRepos(selectRepo) {
    try {
      const r = await fetchJson('api.php?action=repos');
      const repos = Array.isArray(r?.repos) ? r.repos : [];
      repoSelect.innerHTML = '';
      for (const name of repos) {
        const opt = document.createElement('option');
        opt.value = name; opt.textContent = name;
        repoSelect.appendChild(opt);
      }
      // Selección por defecto
      const preferred = selectRepo || 'pruebas';
      if (repos.includes(preferred)) repoSelect.value = preferred;
    } catch (e) {
      // fallback simple si hay error
      repoSelect.innerHTML = '<option value="Yega-API">Yega-API</option>';
    }
  }

  let latestTasks = [];
  function renderTasks(data) {
    const tasks = Array.isArray(data?.tasks) ? data.tasks : (Array.isArray(data) ? data : []);
    latestTasks = tasks;
    renderFilteredTasks();
  }

  function renderFilteredTasks() {
    const tasks = Array.isArray(latestTasks) ? latestTasks : [];
    const filtered = hideClosedToggle && hideClosedToggle.checked
      ? tasks.filter(t => (t?.status || '').toLowerCase() !== 'done' && (t?.status || '').toLowerCase() !== 'cancelled')
      : tasks;
    tasksTable.innerHTML = '';
    if (tasksCount) tasksCount.textContent = `Mostrando ${filtered.length} de ${tasks.length}`;
    for (const t of filtered) {
      const tr = document.createElement('tr');
      const id = t.id || '';
      tr.innerHTML = `
        <td title="${id}">${id.slice(0, 8)}…</td>
        <td>${t.repo || ''}</td>
        <td>${t.status || ''}</td>
        <td>${t.title || ''}</td>
        <td>
          <button data-act="show" data-id="${id}">Ver</button>
          <button data-act="close" data-id="${id}">Cerrar</button>
        </td>
      `;
      tasksTable.appendChild(tr);
    }
  }

  function renderDetail(t) {
    if (!t) { detailEl.textContent = ''; btnReport.disabled = true; btnPlan.disabled = true; return; }
    btnReport.disabled = !t?.id;
    btnPlan.disabled = !(t?.artifacts?.lastChangeset);
    const parts = [];
    parts.push(`ID: ${t.id}`);
    parts.push(`Repo: ${t.repo}`);
    parts.push(`Status: ${t.status}`);
    parts.push(`Title: ${t.title}`);
    if (t.artifacts?.lastSummary) parts.push(`\nLast Summary: ${JSON.stringify(t.artifacts.lastSummary.structured || {}, null, 2)}`);
    if (t.artifacts?.lastChangeset) parts.push(`\nHas Changeset: yes`);
    if (Array.isArray(t.updates)) {
      parts.push('\nUpdates:');
      for (const u of t.updates.slice(-10)) parts.push(`- [${u.at}] ${u.from}: ${u.type}`);
    }
    detailEl.textContent = parts.join('\n');
    detailEl.dataset.taskId = t.id;
  }

  function appendTimeline(events) {
    if (!Array.isArray(events) || !events.length) return;
    for (const e of events) {
      const div = document.createElement('div');
      const type = e?.envelope?.type || e?.event || '';
      const from = e?.from || e?.envelope?.agent?.name || 'orchestrator';
      const taskId = e?.envelope?.task?.id || '';
      div.textContent = `[${e.ts}] ${type} from=${from}${taskId ? ' task=' + taskId.slice(0,8)+'…' : ''}`;
      timelineDiv.prepend(div);
      lastTs = e.ts;
    }
  }

  async function refreshAll() {
    try { renderTasks(await fetchJson('api.php?action=tasks')); } catch {}
    try { appendTimeline(await fetchJson('api.php?action=timeline')); } catch {}
  }

  async function poll() {
    if (!watchToggle.checked) return;
    try { const ev = await fetchJson('api.php?action=timeline&since=' + encodeURIComponent(lastTs)); appendTimeline(ev); } catch {}
  }

  btnPump.addEventListener('click', async () => {
    btnPump.disabled = true; btnPump.textContent = 'Pumping…';
    try { const r = await fetchJson('api.php?action=pump'); if (!r.ok) toast('Pump error'); await refreshAll(); } catch (e) { toast('Pump error'); }
    finally { btnPump.disabled = false; btnPump.textContent = 'Pump'; }
  });

  btnCreate.addEventListener('click', async () => {
    const title = inpTitle.value.trim(); const repo = (repoSelect.value || '').trim();
    if (!title || !repo) { alert('Completa título y repo'); return; }
    btnCreate.disabled = true; btnCreate.textContent = 'Creando…';
    try { const r = await fetchJson('api.php?action=createTask&title=' + encodeURIComponent(title) + '&repo=' + encodeURIComponent(repo)); if (!r.ok) toast('Error creando tarea'); await refreshAll(); }
    catch (e) { toast('Error: ' + e); }
    finally { btnCreate.disabled = false; btnCreate.textContent = 'Crear'; }
  });
  
  // Agregar nuevo repo
  btnAddRepo.addEventListener('click', async () => {
    const name = (newRepoName.value || '').trim();
    if (!name) { alert('Escribe el nombre del repo'); return; }
    btnAddRepo.disabled = true; btnAddRepo.textContent = 'Agregando…';
    try {
      const r = await fetchJson('api.php?action=reposAdd&name=' + encodeURIComponent(name));
      if (!r.ok && r.error) { toast('Error: ' + r.error); }
      await loadRepos(name);
      toast('Repo agregado: ' + name);
      newRepoName.value = '';
    } catch (e) { toast('Error agregando repo'); }
    finally { btnAddRepo.disabled = false; btnAddRepo.textContent = 'Agregar repo'; }
  });

  tasksTable.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('button[data-act]'); if (!btn) return;
    const act = btn.getAttribute('data-act'); const id = btn.getAttribute('data-id');
    if (act === 'show') {
      btn.disabled = true;
      try {
        const r = await fetchJson('api.php?action=taskShow&id=' + encodeURIComponent(id));
        renderDetail(r.task);
        // auto-switch to tasks tab if needed
        switchTab('tasks-tab');
      } catch (e) { toast('Error cargando detalle'); }
      finally { btn.disabled = false; }
    } else if (act === 'close') {
      if (!confirm('Cerrar tarea?')) return;
      btn.disabled = true; btn.textContent = 'Cerrando…';
      try { const r = await fetchJson('api.php?action=closeTask&id=' + encodeURIComponent(id) + '&status=done'); if (!r.ok) toast('Error cerrando tarea'); await refreshAll(); }
      catch (e) { toast('Error: ' + e); }
      finally { btn.disabled = false; btn.textContent = 'Cerrar'; }
    }
  });

  btnReport.addEventListener('click', async () => {
    const id = detailEl.dataset.taskId; if (!id) return;
    btnReport.disabled = true; try { await fetchJson('api.php?action=tasksReport&id=' + encodeURIComponent(id)); await refreshAll(); const r = await fetchJson('api.php?action=taskShow&id=' + encodeURIComponent(id)); renderDetail(r.task); } catch (e) { toast('Error reporte'); } finally { btnReport.disabled = false; }
  });
  btnPlan.addEventListener('click', async () => {
    const id = detailEl.dataset.taskId; if (!id) return;
    btnPlan.disabled = true; try { const r = await fetchJson('api.php?action=tasksPlan&id=' + encodeURIComponent(id)); toast('Plan generado'); await refreshAll(); } catch (e) { toast('Error plan'); } finally { btnPlan.disabled = false; }
  });

  // Tema (claro/pastel vs oscuro/neón)
  function setTheme(t) {
    const root = document.documentElement;
    root.setAttribute('data-theme', t);
    localStorage.setItem('theme', t);
    btnTheme.textContent = 'Tema: ' + (t === 'dark' ? 'Oscuro' : 'Claro');
  }
  const savedTheme = localStorage.getItem('theme') || 'light';
  setTheme(savedTheme);
  btnTheme.addEventListener('click', () => setTheme((document.documentElement.getAttribute('data-theme') === 'dark') ? 'light' : 'dark'));

  // Init
  loadRepos();
  refreshAll();
  setInterval(poll, 2000);

  // Changes form
  btnSendChange.addEventListener('click', async () => {
    const params = new URLSearchParams();
    if (chgTitle.value) params.append('title', chgTitle.value);
    if (chgRepo.value) params.append('repo', chgRepo.value);
    if (chgRoles.value) params.append('roles', chgRoles.value);
    if (chgPayload.value) params.append('payload', chgPayload.value);
    if (chgPrefix.value) params.append('prefix', chgPrefix.value);
    if (chgSuffix.value) params.append('suffix', chgSuffix.value);
    btnSendChange.disabled = true; btnSendChange.textContent = 'Enviando…';
    try { const r = await fetchJson('api.php?action=sendChange&' + params.toString()); chgResult.textContent = JSON.stringify(r, null, 2); toast('Cambio enviado'); }
    catch (e) { chgResult.textContent = String(e); toast('Error enviando cambio'); }
    finally { btnSendChange.disabled = false; btnSendChange.textContent = 'Enviar Cambio'; }
  });

  // Tabs
  function switchTab(id) {
    document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === id));
    document.querySelectorAll('.tab-pane').forEach(p => p.classList.toggle('active', p.id === id));
    if (id === 'chat-tab') { loadChatLogUI(); }
  }
  document.querySelectorAll('.tab').forEach(b => b.addEventListener('click', () => switchTab(b.dataset.tab)));

  // Hide closed toggle persistence
  if (hideClosedToggle) {
    const saved = localStorage.getItem('hideClosed') === '1';
    hideClosedToggle.checked = saved;
    hideClosedToggle.addEventListener('change', () => {
      localStorage.setItem('hideClosed', hideClosedToggle.checked ? '1' : '0');
      renderFilteredTasks();
    });
  }

  // Chat NL
  async function ensureChatSession() {
    if (chatSession) return chatSession;
    const r = await fetchJson('api.php?action=chatNew');
    if (r?.session) { chatSession = r.session; localStorage.setItem('chatSessionId', chatSession); }
    return chatSession;
  }

  async function newChatSession() {
    const r = await fetchJson('api.php?action=chatNew');
    if (r?.session) {
      chatSession = r.session;
      localStorage.setItem('chatSessionId', chatSession);
      chatLog.textContent = '';
      toast('Nueva sesión de chat creada');
      await loadChatLogUI();
    }
  }

  btnChatSend.addEventListener('click', async () => {
    const text = chatText.value.trim(); if (!text) return;
    btnChatSend.disabled = true; btnChatSend.textContent = 'Enviando…';
    try {
      await ensureChatSession();
      const params = new URLSearchParams(); params.append('session', chatSession); params.append('text', text);
      const r = await fetchJson('api.php?action=chatSend&' + params.toString());
      await loadChatLogUI();
      const botLine = (r?.summary ? r.summary : JSON.stringify(r));
      chatLog.textContent = botLine + '\n\n' + chatLog.textContent;
      await refreshAll();
    } catch (e) { toast('Error chat NL'); }
    finally { btnChatSend.disabled = false; btnChatSend.textContent = 'Enviar'; chatText.value=''; }
  });

  if (btnChatNew) {
    btnChatNew.addEventListener('click', async () => {
      btnChatNew.disabled = true; btnChatNew.textContent = 'Creando…';
      try { await newChatSession(); } catch { toast('Error creando sesión'); }
      finally { btnChatNew.disabled = false; btnChatNew.textContent = 'Nueva sesión'; }
    });
  }

  async function loadTasksPage(page, size) {
    const p = Math.max(1, parseInt(page || '1', 10));
    const s = Math.max(1, parseInt(size || '10', 10));
    const r = await fetchJson('api.php?action=tasksPaged&page=' + p + '&size=' + s);
    renderChatTasks(r);
  }
  function renderChatTasks(r) {
    if (!chatTasksDiv) return;
    const items = Array.isArray(r?.items) ? r.items : [];
    const page = r?.page || 1; const pages = r?.pages || 0; const total = r?.total || 0;
    chatTasksDiv.innerHTML='';
    const hdr = document.createElement('div'); hdr.textContent = `Página ${page}/${pages} (total ${total})`; chatTasksDiv.appendChild(hdr);
    const ul = document.createElement('div'); chatTasksDiv.appendChild(ul);
    for (const t of items) {
      const row = document.createElement('div'); row.style.display='flex'; row.style.gap='8px'; row.style.alignItems='center';
      const span = document.createElement('span'); span.textContent = `${(t.id||'').slice(0,8)}… [${t.status||''}] ${t.repo||''} — ${t.title||''}`; span.style.flex='1';
      const btn = document.createElement('button'); btn.textContent = 'Seleccionar'; btn.addEventListener('click', () => { chatText.value = `muestra tarea ${t.id}`; chatText.focus(); });
      row.appendChild(span); row.appendChild(btn); ul.appendChild(row);
    }
    if (chatPageInput) chatPageInput.value = String(page);
  }
  if (btnChatList) btnChatList.addEventListener('click', () => loadTasksPage(chatPageInput?.value, chatSizeInput?.value));
  if (btnChatPrev) btnChatPrev.addEventListener('click', () => { const p = Math.max(1, parseInt(chatPageInput?.value||'1',10)-1); chatPageInput.value = String(p); loadTasksPage(p, chatSizeInput?.value); });
  if (btnChatNext) btnChatNext.addEventListener('click', () => { const p = Math.max(1, parseInt(chatPageInput?.value||'1',10)+1); chatPageInput.value = String(p); loadTasksPage(p, chatSizeInput?.value); });

  async function loadChatLogUI() {
    try {
      await ensureChatSession();
      const r = await fetchJson('api.php?action=chatLog&session=' + encodeURIComponent(chatSession));
      const events = Array.isArray(r?.events) ? r.events : [];
      const lines = [];
      for (const e of events.slice(-60).reverse()) {
        if (e.event === 'session.start') lines.push('--- sesión ' + (e.session || '') + ' ---');
        else if (e.event === 'user') lines.push('> ' + (e.text || ''));
        else if (e.event === 'result') lines.push(String(e.summary || JSON.stringify(e.result || {})));
        else if (e.event === 'watch.summary') lines.push('[watch] ' + (e.payload?.total || 0) + ' eventos');
      }
      chatLog.textContent = lines.join('\n\n');
    } catch {}
  }
})();
