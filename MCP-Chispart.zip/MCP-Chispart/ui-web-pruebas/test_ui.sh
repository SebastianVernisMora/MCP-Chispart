#!/usr/bin/env bash
set -euo pipefail

# Simple smoke tests for the MCP UI Web (PHP + Vanilla JS)
# - Starts PHP built-in server
# - Checks JSON API responds
# - Uses headless Chrome to assert DOM renders tasks

HERE="$(cd "$(dirname "$0")" && pwd)"
PORT="${PORT:-8765}"
HOST="127.0.0.1"
BASE="http://$HOST:$PORT"

log() { printf "[test] %s\n" "$*"; }
fail() { echo "[test] FAIL: $*" >&2; exit 1; }

if ! command -v php >/dev/null 2>&1; then
  fail "PHP CLI no encontrado en PATH"
fi
if ! command -v google-chrome >/dev/null 2>&1; then
  fail "google-chrome no encontrado (se usa para headless DOM)."
fi

log "Levantando servidor PHP en $BASE …"
php -S "$HOST:$PORT" -t "$HERE" >"$HERE/.test_php.log" 2>&1 &
PHP_PID=$!
trap 'kill $PHP_PID >/dev/null 2>&1 || true' EXIT INT TERM

# Esperar a que el servidor esté listo
for i in {1..50}; do
  if curl -sf "$BASE/" >/dev/null; then break; fi
  sleep 0.1
done
curl -sf "$BASE/" >/dev/null || fail "Servidor PHP no respondió en $BASE/"
log "Servidor arriba (pid=$PHP_PID)"

log "Verificando endpoint tasks …"
TASKS_TMP=$(mktemp)
curl -sf "$BASE/api.php?action=tasks" >"$TASKS_TMP" || { rm -f "$TASKS_TMP"; fail "No se pudo leer /api.php?action=tasks"; }
grep -aq '"tasks"' "$TASKS_TMP" || grep -aq '^\[' "$TASKS_TMP" || { head -c 160 "$TASKS_TMP" >&2 || true; rm -f "$TASKS_TMP"; fail "Respuesta tasks no parece JSON esperado"; }
rm -f "$TASKS_TMP"
log "OK tasks JSON"

log "Volcando DOM con headless Chrome …"
DOM=$(google-chrome --headless=new --no-sandbox --disable-gpu --virtual-time-budget=8000 --dump-dom "$BASE/index.php") || {
  echo "--- server log ---" >&2; tail -n +1 "$HERE/.test_php.log" >&2 || true; fail "Chrome headless falló";
}

printf '%s' "$DOM" | grep -q 'id="tasks"' || fail "No se encontró tabla de tareas en DOM"
printf '%s' "$DOM" | grep -q 'class="tab active" data-tab="tasks-tab"' || fail "No se encontró pestaña activa 'Tareas'"

# Debe haber al menos una fila de datos renderizada (busca el botón Ver dentro de filas)
if printf '%s' "$DOM" | grep -q 'data-act="show"'; then
  log "OK tareas renderizadas en DOM"
else
  echo "[warn] No se detectaron filas de tareas renderizadas. DOM parcial:" >&2
  printf '%s' "$DOM" | sed -n '1,120p' >&2
  fail "La UI no parece haber cargado las tareas"
fi

log "Todos los checks pasaron ✅"
exit 0
