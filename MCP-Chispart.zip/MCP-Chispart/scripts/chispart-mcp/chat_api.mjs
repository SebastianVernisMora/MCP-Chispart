#!/usr/bin/env node
// Chat API (for UI) – sesiones persistentes + NL → acciones orquestador + resúmenes en español
import { mkdirSync, existsSync, readFileSync, writeFileSync, appendFileSync } from 'fs';
import { join } from 'path';
import { spawnSync } from 'child_process';

const ROOT = process.cwd();
const CHATS_ROOT = join(ROOT, '.mcp', 'chats');
const STATE_ROOT = process.env.MCP_STATE_ROOT || join(ROOT, '.mcp', 'state');
const TIMELINE = join(STATE_ROOT, 'timeline.jsonl');

const BB_API_URL = process.env.BLACKBOX_API_URL || 'https://api.blackbox.ai/v1/chat/completions';
const BB_API_KEY = process.env.BLACKBOX_API_KEY || '';
const BB_MODEL = process.env.BLACKBOX_MODEL || process.env.BLACKBOX_MODEL_SUMMARY || 'blackboxai/anthropic/claude-3.5-haiku';
const BB_TEMPERATURE = process.env.BLACKBOX_TEMPERATURE;
const BB_TOP_P = process.env.BLACKBOX_TOP_P;
const BB_MAX_TOKENS = process.env.BLACKBOX_MAX_TOKENS;
const BB_MAX_INPUT_CHARS = Number(process.env.BLACKBOX_MAX_INPUT_CHARS || '60000');

function nowISO() { return new Date().toISOString(); }
function uuid() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => { const r = Math.random()*16|0; const v = c==='x'?r:(r&0x3|0x8); return v.toString(16); }); }
function ensureDirs() { if (!existsSync(CHATS_ROOT)) mkdirSync(CHATS_ROOT, { recursive: true }); }

function loadAgentsRepos() {
  try {
    const cfgPath = new URL('./config/agents.json', import.meta.url);
    const cfg = JSON.parse(readFileSync(cfgPath, 'utf-8'));
    const repos = new Set();
    for (const a of cfg.agents || []) for (const r of (a.repos || [])) repos.add(r);
    return Array.from(repos);
  } catch { return []; }
}

async function callBlackbox(prompt) {
  if (!BB_API_KEY) throw new Error('BLACKBOX_API_KEY no configurada');
  // Truncar prompt para evitar sobrepasar contexto
  const safePrompt = String(prompt || '')
    .replace(/\s+$/,'')
    .slice(0, Math.max(1000, BB_MAX_INPUT_CHARS));
  const body = { model: BB_MODEL, messages: [{ role: 'user', content: safePrompt }] };
  if (BB_TEMPERATURE !== undefined) body.temperature = Number(BB_TEMPERATURE);
  if (BB_TOP_P !== undefined) body.top_p = Number(BB_TOP_P);
  if (BB_MAX_TOKENS !== undefined) body.max_tokens = Number(BB_MAX_TOKENS);
  const res = await fetch(BB_API_URL, { method: 'POST', headers: { 'content-type': 'application/json', 'authorization': `Bearer ${BB_API_KEY}` }, body: JSON.stringify(body) });
  const text = await res.text(); let data = null; try { data = JSON.parse(text); } catch {}
  const content = data?.choices?.[0]?.message?.content || data?.output || text; return content;
}

async function explain(kind, data, options = {}) {
  const style = options.style || 'breve y accionable';
  const prompt = [
    'Eres un asistente técnico. Explica resultados de orquestación de tareas en español, de forma ' + style + '.',
    'No devuelvas JSON ni markdown, solo texto claro con bullets cuando convenga.',
    `Contexto (${kind}):`,
    typeof data === 'string' ? data : JSON.stringify(data, null, 2)
  ].join('\n\n');
  const content = await callBlackbox(prompt);
  return String(content).replace(/```[a-z]*\n?|```/gi, '').trim();
}

function tryExtractJson(text) { const m = text.match(/```json\s*([\s\S]*?)```/i); if (m) { try { return JSON.parse(m[1]); } catch {} } try { return JSON.parse(text); } catch {} return null; }

function runOrch(args, { json = false } = {}) {
  // Usa el mismo binario de Node que ejecuta este script (asegura Node 18+)
  const nodeBin = process.execPath || 'node';
  const cmd = [nodeBin, 'scripts/chispart-mcp/orchestrator.mjs', ...args];
  const res = spawnSync(cmd[0], cmd.slice(1), { encoding: 'utf-8' });
  const out = (res.stdout || '').trim(); const err = (res.stderr || '').trim();
  return { ok: res.status === 0, stdout: out, stderr: err, json: json ? safeJson(out) : null };
}
function safeJson(s) { try { return JSON.parse(s); } catch { return null; } }
function writeSession(session, obj) { const dir = join(CHATS_ROOT, session); if (!existsSync(dir)) mkdirSync(dir, { recursive: true }); appendFileSync(join(dir, 'log.jsonl'), JSON.stringify({ ts: nowISO(), ...obj }) + '\n'); }

function heuristicIntent(text, repos) {
  const t = text.toLowerCase();
  const idMatch = text.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
  if (/\bpump\b/.test(t)) return { action: 'pump', args: {} };
  if (/(lista|list)\s+(tarea|tareas)/.test(t)) return { action: 'list_tasks', args: {} };
  if (/(muestra|mostrar|show)\b/.test(t) && idMatch) return { action: 'show_task', args: { taskId: idMatch[0] } };
  if (/(cierra|cerrar|close)\b/.test(t) && idMatch) return { action: 'close_task', args: { taskId: idMatch[0] } };
  if (/(reporte|report)\b/.test(t) && idMatch) return { action: 'report_task', args: { taskId: idMatch[0] } };
  if (/(plan)\b/.test(t) && idMatch) return { action: 'plan_task', args: { taskId: idMatch[0] } };
  if (/(crea|crear|create)\b/.test(t)) {
    // extraer título entre comillas si existe
    const m = text.match(/"([^"]+)"/);
    const title = m ? m[1] : text.replace(/^(.*?(crea(r)?|create))\s*/i,'');
    const repo = repos.includes('pruebas') ? 'pruebas' : (repos[0] || 'global');
    return { action: 'create_task', args: { title: title.trim() || 'Nueva tarea', repo } };
  }
  return { action: 'help', args: {} };
}

async function handleSend(session, text, repoOverride) {
  const repos = loadAgentsRepos();
  writeSession(session, { event: 'user', text });
  let intent = null; let content = '';
  try {
    const sys = `Convierte la solicitud del usuario en un JSON (en bloque \`\`\`json) con el siguiente esquema exacto:\n{"version":"mcp/chat-intent@1","action":"list_tasks|show_task|create_task|send_change|close_task|report_task|plan_task|pump|watch_on|watch_off|help|exit","args":{}}\nCampos args por acción:\n- create_task: {"title":"...","repo":"...","roles":["coordinator","qa"]}\n- send_change: {"title":"...","repo":"...","roles":["analysis","dev-support"],"payload":{}}\n- show_task/close_task/report_task/plan_task: {"taskId":"..."}\n- list_tasks/pump/watch_on/watch_off/help/exit: {}.\nRepos válidos: ${repos.join(', ')}.`;
    content = await callBlackbox(sys + '\nUsuario: ' + text);
    intent = tryExtractJson(content);
  } catch {}
  if (!intent || !intent.action) intent = heuristicIntent(text, repos);
  writeSession(session, { event: 'intent', raw: content, intent });
  const a = intent.action || '';
  let result = null; let summary = '';
  switch (a) {
    case 'list_tasks': {
      const r = runOrch(['tasks', 'list', '--json'], { json: true });
      const arr = Array.isArray(r.json) ? r.json : [];
      // Reducir volumen: tomar últimas 30 tareas (por updatedAt si existe) y campos mínimos
      const sorted = arr.slice().sort((a,b)=> String(a.updatedAt||'').localeCompare(String(b.updatedAt||'')) ).slice(-30);
      const minimal = sorted.map(t => ({ id: t.id, repo: t.repo, status: t.status, title: t.title, updatedAt: t.updatedAt }));
      result = minimal;
      summary = await explain('tasks.list', minimal);
      break;
    }
    case 'show_task': {
      const id = intent.args?.taskId; if (!id) { result = { error: 'Falta taskId' }; break; }
      const r = runOrch(['tasks', 'show', id]);
      const full = safeJson(r.stdout) || {};
      // Limitar updates y quitar payloads pesados
      if (Array.isArray(full.updates)) full.updates = full.updates.slice(-15).map(u => ({ at: u.at, from: u.from, type: u.type }));
      result = full;
      summary = await explain('tasks.show', { id: full.id, repo: full.repo, status: full.status, title: full.title, updates: full.updates });
      break;
    }
    case 'create_task': {
      const rp = repoOverride || intent.args?.repo || repos[0] || 'global';
      const title = intent.args?.title || text; const roles = Array.isArray(intent.args?.roles) && intent.args.roles.length ? intent.args.roles.join(',') : '';
      const r = roles ? runOrch(['task', title, '--repo', rp, '--roles', roles]) : runOrch(['task', title, '--repo', rp]);
      result = { created: true, title, repo: rp, roles: roles || '(default)' }; summary = await explain('task.create', result); break;
    }
    case 'send_change': {
      const rp = repoOverride || intent.args?.repo || repos[0] || 'global';
      const title = intent.args?.title || text; const roles = Array.isArray(intent.args?.roles) && intent.args.roles.length ? intent.args.roles.join(',') : '';
      const payload = intent.args?.payload ? JSON.stringify(intent.args.payload) : '{}';
      const args = ['send', 'change', title, '--repo', rp]; if (roles) args.push('--roles', roles); args.push('--payload', payload);
      const r = runOrch(args); result = { dispatched: true, title, repo: rp, roles: roles || '(default)' }; summary = await explain('change.request', { title, repo: rp, roles: roles || '(default)' }); break;
    }
    case 'close_task': {
      const id = intent.args?.taskId; if (!id) { result = { error: 'Falta taskId' }; break; }
      const r = runOrch(['tasks', 'close', id, '--status', 'done']); result = { closed: true, taskId: id }; summary = await explain('task.close', result); break;
    }
    case 'report_task': {
      const id = intent.args?.taskId; if (!id) { result = { error: 'Falta taskId' }; break; }
      const r = runOrch(['tasks', 'report', id]); result = safeJson(r.stdout) || r.stdout; summary = await explain('tasks.report', result); break;
    }
    case 'plan_task': {
      const id = intent.args?.taskId; if (!id) { result = { error: 'Falta taskId' }; break; }
      const r = runOrch(['tasks', 'plan', id]); result = safeJson(r.stdout) || r.stdout; summary = await explain('tasks.plan', result); break;
    }
    case 'pump': { runOrch(['pump']); result = { pump: true }; summary = 'Se bombeó el timeline y se reenrutaron eventos.'; break; }
    case 'help': default: { result = { info: 'Pide crear/mostrar/cerrar tarea, reporte, plan, enviar cambio o pump.' }; summary = 'Puedes pedir crear tareas, listar, mostrar, cerrar, reporte, plan y pump.'; }
  }
  writeSession(session, { event: 'result', intent: a, result, summary });
  return { ok: true, session, intent: a, result, summary };
}

async function main() {
  ensureDirs();
  const [, , cmd, ...rest] = process.argv;
  if (cmd === 'new') {
    const session = uuid();
    const repos = loadAgentsRepos();
    writeSession(session, { event: 'session.start', session, repos });
    console.log(JSON.stringify({ ok: true, session, repos }, null, 2));
    return;
  }
  if (cmd === 'send') {
    const session = rest[0]; const text = rest.slice(1).join(' ').trim().replace(/^"|"$/g, '');
    if (!session || !text) { console.error('Uso: chat_api.mjs send <session> "texto"'); process.exit(1); }
    const repo = process.env.MCP_CHAT_DEFAULT_REPO || '';
    const out = await handleSend(session, text, repo);
    console.log(JSON.stringify(out, null, 2));
    return;
  }
  console.log(JSON.stringify({ ok: false, error: 'Uso: chat_api.mjs {new|send <sid> "texto">}' }));
}

main();
