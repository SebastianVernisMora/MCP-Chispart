#!/usr/bin/env node
// Tester agent: runs UI smoke tests and reports result.test to QA
import { readdirSync, readFileSync, writeFileSync, rmSync, existsSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';
import { exec } from 'child_process';

const AGENT_NAME = process.env.MCP_AGENT_NAME || 'tester';
const ROLE = process.env.MCP_AGENT_ROLE || 'tester';
const ROOT = process.env.MCP_MAILBOX_ROOT || '.mcp/mailboxes';
const INBOX = join(ROOT, `${AGENT_NAME}.in`);
const OUTBOX = join(ROOT, `${AGENT_NAME}.out`);

function ensure() {
  if (!existsSync(INBOX)) mkdirSync(INBOX, { recursive: true });
  if (!existsSync(OUTBOX)) mkdirSync(OUTBOX, { recursive: true });
}

function nowISO() { return new Date().toISOString(); }

function emit(envelope, payload) {
  const out = {
    id: envelope.id,
    type: 'result.test',
    agent: { name: AGENT_NAME, role: ROLE },
    target: { roles: ['qa'] },
    task: envelope.task,
    payload,
    meta: { ...envelope.meta, timestamp: nowISO() }
  };
  const file = join(OUTBOX, `${out.id}-${Date.now()}.json`);
  writeFileSync(file, JSON.stringify(out, null, 2));
}

function runTestScript(repo) {
  return new Promise((resolve) => {
    // Choose script: prefer ui-web-pruebas when repo=pruebas; fallback to ui-web
    const base = process.env.MCP_TEST_UI_DIR || (repo === 'pruebas' ? 'ui-web-pruebas' : 'ui-web');
    const script = process.env.MCP_TEST_UI_SCRIPT || join(base, 'test_ui.sh');
    const env = { ...process.env, PORT: process.env.MCP_TEST_PORT || '8875' };
    const child = exec(`bash ${script}`, { env, cwd: process.cwd() });
    let buf = '';
    child.stdout.on('data', d => { buf += String(d); });
    child.stderr.on('data', d => { buf += String(d); });
    child.on('exit', (code) => {
      const passed = code === 0;
      resolve({ passed, output: buf.slice(0, 4000) });
    });
    child.on('error', () => resolve({ passed: false, output: buf.slice(0, 4000) }));
  });
}

async function handle(env) {
  const t = env?.type || '';
  if (t.endsWith('.ack') || t.startsWith('log.') || t.startsWith('result.')) return;
  if (t === 'task.create') {
    const repo = env?.task?.repo || '';
    try {
      const { passed, output } = await runTestScript(repo);
      emit(env, { provider: 'local', kind: 'ui-smoke', status: passed ? 'passed' : 'failed', output });
    } catch (e) {
      emit(env, { provider: 'local', kind: 'ui-smoke', status: 'failed', error: String(e?.message || e) });
    }
  }
}

function loopOnce() {
  const files = existsSync(INBOX) ? readdirSync(INBOX) : [];
  for (const f of files) {
    if (!f.endsWith('.json')) continue;
    const full = join(INBOX, f);
    let env = null; try { env = JSON.parse(readFileSync(full, 'utf-8')); } catch {}
    rmSync(full, { force: true });
    if (env) handle(env);
  }
}

function main() {
  ensure();
  console.log(`[${AGENT_NAME}] tester running; inbox=${INBOX}, outbox=${OUTBOX}`);
  loopOnce();
  setInterval(loopOnce, Number(process.env.MCP_POLL_MS || '1000'));
}

main();
