#!/usr/bin/env node
// Qwen adapter (MVP): integra vía HTTP (OpenAI-compatible) o CLI.
// Config por env vars. Si hay QWEN_API_URL y QWEN_API_KEY usa HTTP compatible; en caso contrario usa CLI.

import { readdirSync, readFileSync, writeFileSync, rmSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';
import { spawn } from 'child_process';

const AGENT_NAME = process.env.MCP_AGENT_NAME || 'qwen';
const ROLE = process.env.MCP_AGENT_ROLE || 'analysis';
const ROOT = process.env.MCP_MAILBOX_ROOT || '.mcp/mailboxes';
const INBOX = join(ROOT, `${AGENT_NAME}.in`);
const OUTBOX = join(ROOT, `${AGENT_NAME}.out`);

// Config HTTP (compatible mode)
const QWEN_API_URL = process.env.QWEN_API_URL || '';
const QWEN_API_KEY = process.env.QWEN_API_KEY || '';
const QWEN_MODEL = process.env.QWEN_MODEL || 'qwen3-coder-plus';
const QWEN_TEMPERATURE = process.env.QWEN_TEMPERATURE;
const QWEN_TOP_P = process.env.QWEN_TOP_P;
const QWEN_MAX_TOKENS = process.env.QWEN_MAX_TOKENS;

// Config CLI (fallback)
const QWEN_CLI_CMD = process.env.QWEN_CLI_CMD || 'qwen';
const QWEN_CLI_ARGS = (process.env.QWEN_CLI_ARGS || '').split(' ').filter(Boolean); // e.g. "chat -m Qwen2.5-72B-Instruct"

function ensure() {
  if (!existsSync(INBOX)) mkdirSync(INBOX, { recursive: true });
  if (!existsSync(OUTBOX)) mkdirSync(OUTBOX, { recursive: true });
}
function nowISO() { return new Date().toISOString(); }

function outEnvelope(inEnv, type, payload) {
  return {
    id: inEnv.id,
    type,
    agent: { name: AGENT_NAME, role: ROLE },
    target: inEnv.target,
    task: inEnv.task,
    payload,
    meta: { ...inEnv.meta, timestamp: nowISO() }
  };
}

function writeOut(env) {
  const file = join(OUTBOX, `${env.id}-${Date.now()}.json`);
  writeFileSync(file, JSON.stringify(env, null, 2));
}

function promptFromEnvelope(envelope) {
  const { type, task, payload } = envelope;
  const repo = task?.repo || 'global';
  const title = task?.title || '';
  const desc = task?.description || '';
  const intent = `Evento=${type}, Repo=${repo}`;
  const input = typeof payload === 'string' ? payload : JSON.stringify(payload || {}, null, 2);
  return [
    `Ayuda con análisis/plan de cambios para el ecosistema Yega.`,
    intent,
    `Tarea: ${title}`,
    desc ? `Descripción: ${desc}` : '',
    input ? `Contexto/Payload:\n${input}` : ''
  ].filter(Boolean).join('\n\n');
}

async function runQwenHTTP(prompt) {
  if (!QWEN_API_URL || !QWEN_API_KEY) return { ok: false, status: 0, error: 'HTTP config missing' };
  if (typeof fetch !== 'function') return { ok: false, status: 0, error: 'fetch not available (Node < 18)' };
  const url = QWEN_API_URL.replace(/\/$/, '') + '/chat/completions';
  const body = { model: QWEN_MODEL, messages: [{ role: 'user', content: prompt }] };
  if (QWEN_TEMPERATURE !== undefined) body.temperature = Number(QWEN_TEMPERATURE);
  if (QWEN_TOP_P !== undefined) body.top_p = Number(QWEN_TOP_P);
  if (QWEN_MAX_TOKENS !== undefined) body.max_tokens = Number(QWEN_MAX_TOKENS);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'authorization': `Bearer ${QWEN_API_KEY}` },
      body: JSON.stringify(body)
    });
    const text = await res.text();
    let data = null; try { data = JSON.parse(text); } catch {}
    const content = data?.choices?.[0]?.message?.content || data?.output || text;
    return { ok: res.ok, status: res.status, content, data };
  } catch (e) {
    return { ok: false, status: 0, error: String(e?.message || e) };
  }
}

function runQwenCLI(prompt) {
  return new Promise((resolve) => {
    const cp = spawn(QWEN_CLI_CMD, QWEN_CLI_ARGS, { stdio: ['pipe', 'pipe', 'pipe'] });
    let out = '', err = '';
    cp.stdout.on('data', d => out += d.toString());
    cp.stderr.on('data', d => err += d.toString());
    cp.on('error', e => {
      // Captura error de spawn (binario ausente, permisos, etc.)
      resolve({ code: -1, stdout: out.trim(), stderr: `spawn error: ${e?.message || e}` });
    });
    cp.on('close', code => {
      resolve({ code, stdout: out.trim(), stderr: err.trim() });
    });
    try { cp.stdin.write(prompt); cp.stdin.end(); } catch {}
  });
}

async function handle(envelope) {
  const prompt = promptFromEnvelope(envelope);
  // Prefer HTTP if configured
  let content = null; let provider = null; let ok = false; let stderr = '';
  if (QWEN_API_URL && QWEN_API_KEY) {
    const r = await runQwenHTTP(prompt);
    ok = !!r.ok; content = r.content; provider = 'qwen-http'; stderr = r.error || '';
  } else {
    const r = await runQwenCLI(prompt);
    ok = (r.code === 0); content = r.stdout; provider = 'qwen-cli'; stderr = r.stderr || '';
  }
  if (ok) {
    switch (envelope.type) {
      case 'task.create':
        writeOut(outEnvelope(envelope, 'result.review', { provider, content, kind: 'analysis' }));
        break;
      case 'change.request':
        writeOut(outEnvelope(envelope, 'result.review', { provider, content, kind: 'change-plan' }));
        break;
      case 'task.update':
        writeOut(outEnvelope(envelope, 'result.review', { provider, content, kind: 'update-analysis' }));
        break;
      default:
        writeOut(outEnvelope(envelope, 'log.info', { message: 'processed', provider }));
    }
  } else {
    writeOut(outEnvelope(envelope, 'log.error', { provider: provider || 'qwen', stderr }));
  }
}

async function loopOnce() {
  const files = existsSync(INBOX) ? readdirSync(INBOX) : [];
  for (const f of files) {
    if (!f.endsWith('.json')) continue;
    const full = join(INBOX, f);
    try {
      const env = JSON.parse(readFileSync(full, 'utf-8'));
      await handle(env);
    } catch (e) {
      writeOut({ id: 'unknown', type: 'log.error', agent: { name: AGENT_NAME, role: ROLE }, meta: { timestamp: nowISO(), version: '2.0' }, payload: { error: String(e) } });
    }
    try { rmSync(full); } catch {}
  }
}

async function main() {
  ensure();
  const interval = Number(process.env.MCP_POLL_MS || '1500');
  console.log(`[${AGENT_NAME}] adapter running; inbox=${INBOX}, outbox=${OUTBOX}`);
  await loopOnce();
  setInterval(() => { loopOnce(); }, interval);
}

main();
